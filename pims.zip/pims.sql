-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2017 at 02:20 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pims`
--

-- --------------------------------------------------------

--
-- Table structure for table `accont2`
--

CREATE TABLE `accont2` (
  `accId` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `supId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accont2`
--

INSERT INTO `accont2` (`accId`, `balance`, `supId`) VALUES
(5, -8000, 7),
(6, -4000, 6);

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `accId` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `cid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`accId`, `balance`, `cid`) VALUES
(3, 500030, 3),
(4, 16, 5);

-- --------------------------------------------------------

--
-- Table structure for table `bidhaa`
--

CREATE TABLE `bidhaa` (
  `bid` int(11) NOT NULL,
  `bname` varchar(50) NOT NULL,
  `maelezo` varchar(50) NOT NULL,
  `buyprice` int(11) NOT NULL,
  `sellprice` int(11) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bidhaa`
--

INSERT INTO `bidhaa` (`bid`, `bname`, `maelezo`, `buyprice`, `sellprice`, `status`) VALUES
(1, 'unga wa sembe', 'azam', 0, 0, 'inactive'),
(2, 'unga wa ngano ', 'azam', 0, 0, 'active'),
(3, 'mchele', 'bopar', 0, 0, 'active'),
(4, 'apple', 'c', 10, 0, 'active'),
(5, 'mast jasmin', '', 200, 26000, 'active'),
(6, 'mast unga', '', 0, 0, 'inactive'),
(7, 'brinto 2l', '', 10, 5500, 'active'),
(8, 'mast unga', 'eeee', 0, 2000, 'inactive'),
(9, 'mast unga', 'eee', 15000, 20000, 'active'),
(10, 'ameera', '', 10, 57000, 'active'),
(11, 'give', '', 10, 800, 'active'),
(12, 'dddd', 'dddd', 56, 34, 'inactive'),
(13, 'ddddddd', '', 34, 34, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cid` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `location` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cid`, `fname`, `mname`, `lname`, `location`, `status`) VALUES
(1, 'Othman', 'rubea', 'Othman', 'gulioni', 'active'),
(2, 'Saghir', 'Saghir', 'Saghir', 'K/maiti', 'active'),
(3, 'ali', ' bname', 'order ', 'order by bname', 'inactive'),
(4, 'ali', 'mzee', 'haji', 'kama', 'inactive'),
(5, 'Ali', 'Mzee', 'Haji', 'kama', 'inactive'),
(6, 'Najma', 'Omar', 'Othman', 'k/maiti', 'active'),
(7, 'kireko', 'kireko', 'kireko', 'k/maiti', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `customer2`
--

CREATE TABLE `customer2` (
  `cid` int(11) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `location` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer2`
--

INSERT INTO `customer2` (`cid`, `fname`, `mname`, `lname`, `location`, `status`) VALUES
(1, 'Aliiiiiiiiiiiiiiiiii', 'mzeeiiiiiiiiiiiiiiii', 'Hajiiiiiiiiiiiiiiiii', 'kamaiiiiiiiiiiiiiiiiiiiiiii', 'inactive'),
(2, 'alioooooo', 'mzeeooooooo', 'hajiooooooooooo', 'kamaoooooooo', 'inactive'),
(3, 'fahmi', 'mohd', 'juma', 'shimoni', 'active'),
(4, 'ali', 'musa', 'makame', 'jirani', 'active'),
(5, 'ame', 'malik', 'ame', 'kama', 'active'),
(6, 'amaa', 'mama', ' a ma', 'mama', 'inactive'),
(7, 'mamma', 'kdkdk', 'aakk', 'kakak', 'inactive'),
(8, 'mavi', '', 'mavi', 'mavi', 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `oid` int(11) NOT NULL,
  `odate` date NOT NULL,
  `cid` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `ordertype` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`oid`, `odate`, `cid`, `customerId`, `ordertype`) VALUES
(23, '2017-09-17', 1, 3, 'credit'),
(24, '2017-09-18', 1, 3, 'cash'),
(25, '2017-09-18', 1, 3, 'credit'),
(26, '2017-09-18', 1, 4, 'cash'),
(27, '2017-09-18', 2, 5, 'credit'),
(28, '2017-09-18', 1, 3, 'credit'),
(29, '2017-09-18', 1, 3, 'cash'),
(30, '2017-09-21', 1, 3, 'credit');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `odid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `oid` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`odid`, `bid`, `oid`, `price`, `quantity`) VALUES
(39, 4, 23, 2, 5),
(40, 7, 23, 2, 5),
(41, 4, 24, 2, 6),
(42, 4, 25, 2, 4),
(43, 7, 25, 3, 5),
(44, 4, 26, 3, 5),
(45, 2, 26, 3, 1),
(46, 7, 27, 4, 4),
(47, 7, 28, 1, 7),
(48, 7, 29, 8, 8),
(49, 10, 30, 50000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `pdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pid`, `cid`, `amount`, `pdate`) VALUES
(1, 3, 10, '2017-09-18'),
(2, 3, 10, '2017-09-18');

-- --------------------------------------------------------

--
-- Table structure for table `payment2`
--

CREATE TABLE `payment2` (
  `pid` int(11) NOT NULL,
  `supId` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `pdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment2`
--

INSERT INTO `payment2` (`pid`, `supId`, `amount`, `pdate`) VALUES
(2, 6, 700, '2017-09-21'),
(3, 7, 2000, '2017-09-21');

-- --------------------------------------------------------

--
-- Table structure for table `returnin`
--

CREATE TABLE `returnin` (
  `rid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rdate` date NOT NULL,
  `bid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returnin`
--

INSERT INTO `returnin` (`rid`, `quantity`, `rdate`, `bid`) VALUES
(1, 10, '2017-09-21', 10),
(2, 5, '2017-09-21', 10),
(3, 5, '2017-09-21', 10);

-- --------------------------------------------------------

--
-- Table structure for table `returnout`
--

CREATE TABLE `returnout` (
  `rid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rdate` date NOT NULL,
  `bid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returnout`
--

INSERT INTO `returnout` (`rid`, `quantity`, `rdate`, `bid`) VALUES
(1, 5, '2017-09-21', 10);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `sid` int(11) NOT NULL,
  `jinalamtumiaji` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `address` varchar(30) NOT NULL,
  `nywilayamtumiaji` varchar(50) NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`sid`, `jinalamtumiaji`, `fname`, `mname`, `lname`, `gender`, `address`, `nywilayamtumiaji`, `role`, `status`) VALUES
(1, 'ochu', 'othman', 'ali', 'makame', 'male', 'bububu', '51843c1209a59617357eb7ac6ee8a40a', 'boss', 'active'),
(2, 'zege', 'Alawi', 'abdulsamad', 'abdula', 'male', 'Makadara', '97afd7e410fdd3bca25e112a45fe0644', 'staff', 'active'),
(3, 'afaf', 'adfaf', 'dddd', 'ddd', 'male', 'dddddd', '60a1e609569d916c9d3db8d087f7aa83', 'staff', 'inactive'),
(4, 'ddddddddd', 'dd', 'ddd', 'ddd', 'male', 'dddd', 'c2496e9d1d89ebced6246b27a249e678', 'boss', 'inactive'),
(5, 'dfafaf', 'adfaf', 'dddd', 'ddd', 'male', 'ddd', 'dbbe75ff07ae57ca08c6b519b2628edc', 'boss', 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `sid` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `stockin` int(11) NOT NULL,
  `stockout` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`sid`, `bid`, `stockin`, `stockout`) VALUES
(17, 10, 175, 0),
(18, 4, 570, 0),
(19, 7, 700, 0),
(20, 11, 300, 0);

-- --------------------------------------------------------

--
-- Table structure for table `stock2`
--

CREATE TABLE `stock2` (
  `sid2` int(11) NOT NULL,
  `bid` int(11) NOT NULL,
  `stockin` int(11) NOT NULL,
  `sdate` date NOT NULL,
  `supId` int(11) NOT NULL,
  `type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock2`
--

INSERT INTO `stock2` (`sid2`, `bid`, `stockin`, `sdate`, `supId`, `type`) VALUES
(32, 10, 200, '2017-09-21', 7, 'credit'),
(33, 4, 300, '2017-09-21', 7, 'credit'),
(34, 7, 200, '2017-09-21', 7, 'cash'),
(35, 4, 200, '2017-09-21', 7, 'credit'),
(36, 7, 30, '2017-09-21', 7, 'cash'),
(37, 7, 70, '2017-09-21', 6, 'cash'),
(38, 4, 70, '2017-09-21', 6, 'credit'),
(39, 11, 300, '2017-09-21', 7, 'credit'),
(40, 7, 400, '2017-09-21', 6, 'credit');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `supId` int(11) NOT NULL,
  `supname` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`supId`, `supname`, `location`, `status`) VALUES
(4, 'azam', 'keli', 'inactive'),
(5, 'azam', 'neyo', 'inactive'),
(6, 'bopar', 'kwarara', 'active'),
(7, 'azam', 'malindi', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accont2`
--
ALTER TABLE `accont2`
  ADD PRIMARY KEY (`accId`);

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`accId`);

--
-- Indexes for table `bidhaa`
--
ALTER TABLE `bidhaa`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `customer2`
--
ALTER TABLE `customer2`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`odid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `payment2`
--
ALTER TABLE `payment2`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `returnin`
--
ALTER TABLE `returnin`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `returnout`
--
ALTER TABLE `returnout`
  ADD PRIMARY KEY (`rid`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `username` (`jinalamtumiaji`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `stock2`
--
ALTER TABLE `stock2`
  ADD PRIMARY KEY (`sid2`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`supId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accont2`
--
ALTER TABLE `accont2`
  MODIFY `accId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `accId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `bidhaa`
--
ALTER TABLE `bidhaa`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `customer2`
--
ALTER TABLE `customer2`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `oid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `odid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `payment2`
--
ALTER TABLE `payment2`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `returnin`
--
ALTER TABLE `returnin`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `returnout`
--
ALTER TABLE `returnout`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `stock`
--
ALTER TABLE `stock`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `stock2`
--
ALTER TABLE `stock2`
  MODIFY `sid2` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `supId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
